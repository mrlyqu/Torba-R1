LISTA KONTROLNA PSP R1 — PROJEKT APLIKACJI ANDROID

To jest projekt źródłowy aplikacji Android opakowującej oryginalną listę HTML.
Aplikacja uruchamia listę lokalnie z zasobów APK — nie wymaga hostingu ani serwera.

FUNKCJE
- zachowana logika listy kontrolnej z oryginalnego pliku HTML,
- zapis stanu w pamięci aplikacji (localStorage WebView),
- import i eksport kopii JSON przez systemowy wybór plików Android,
- działanie bez internetu; opcjonalna synchronizacja Firebase wymaga sieci i konfiguracji.
- czcionki zewnętrzne usunięto, aby interfejs nie pobierał ich z internetu.

JAK ZBUDOWAĆ APK
1. Na komputerze zainstaluj Android Studio.
2. Rozpakuj ZIP.
3. W Android Studio wybierz Open i wskaż folder PSP_R1_Android_Project.
4. Poczekaj na synchronizację Gradle (pierwsze pobranie narzędzi wymaga internetu).
5. Wybierz Build > Build Bundle(s) / APK(s) > Build APK(s).
6. Gotowy plik znajdziesz w app/build/outputs/apk/debug/app-debug.apk.
7. Przenieś APK na telefon i zainstaluj. Android może poprosić o zezwolenie na instalację z tego źródła.

UWAGA
- Samo zbudowanie APK wymaga Android SDK/Gradle; w tym środowisku nie ma tych narzędzi,
  dlatego ZIP zawiera kompletny projekt do zbudowania, a nie gotowy APK.
- Nie odinstalowuj aplikacji bez wykonania eksportu kopii JSON — odinstalowanie może
  usunąć lokalne dane aplikacji.
- Uprawnienie INTERNET jest pozostawione wyłącznie dla opcjonalnej funkcji synchronizacji.
  Podstawowa lista działa offline.
